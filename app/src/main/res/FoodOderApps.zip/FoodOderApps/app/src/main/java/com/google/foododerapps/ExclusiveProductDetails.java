package com.google.foododerapps;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;

public class ExclusiveProductDetails extends AppCompatActivity {

    String imageUrl, productTile;
    RoundedImageView roundedImageCat1;
    TextView productTitle;
    String productIngredients;
    double productRating;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exclusive_product_details);

        imageUrl = getIntent().getStringExtra("image");
        productTile = getIntent().getStringExtra("name");



        // Step 2: findViewById for the RoundedImageView
        roundedImageCat1 = findViewById(R.id.roundedImageCat1);
        productTitle = findViewById(R.id.productTitle);

        productTitle.setText(productTile);
        Glide.with(this)
                .load(imageUrl)
                .into(roundedImageCat1);


    }



    }
