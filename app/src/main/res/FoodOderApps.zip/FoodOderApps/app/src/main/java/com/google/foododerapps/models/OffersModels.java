package com.google.foododerapps.models;

public class OffersModels {

    int img;

    public OffersModels(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
