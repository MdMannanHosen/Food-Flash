package com.google.foododerapps.models;

public class SliderData {

    private int imgUrl;

    // Constructor method.
    public SliderData(int imgUrl) {
        this.imgUrl = imgUrl;
    }

    // Getter method
    public int getImgUrl() {
        return imgUrl;
    }

    // Setter method
    public void setImgUrl(int imgUrl) {
        this.imgUrl = imgUrl;
    }
}

